// IMPORTS
import document from "document";
import { charger, battery } from "power";
import {simpleProgressBar} from './simpleProgressBar.js'

// Create a new Simple Progress Bar for the battery level
const spbBattery = new simpleProgressBar({id:'spbBattery', fgColor: 'lime', bgColor: 'darkgreen'});


// Update the Battery progress bar
function updateBattery() {

  spbBattery.value = battery.chargeLevel || 0;
  
}

// Get notified when battery level changes
battery.addEventListener('change', updateBattery);


// Force initial Battery Update
updateBattery();