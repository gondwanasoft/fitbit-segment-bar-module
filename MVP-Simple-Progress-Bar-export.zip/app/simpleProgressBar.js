import document from 'document'

export function simpleProgressBar({ id, fgColor, bgColor, value}) {
  
  this.root             = typeof id === 'string' ? document.getElementById(id) : id
  this.bgBar            = this.root.getElementById('bgBar')
  this.bgBar.style.fill = bgColor || 'grey'
  this.fgBar            = this.root.getElementById('fgBar')
  this.fgBar.style.fill = fgColor || 'white'
  this.value            = value || 0
   
  // Set foreground bar width (based on value, if set) and height 
  this.fgBar.width = this.root.width * this.value / 100
    
  this.redraw = () => {
    
    this.fgBar.width = this.root.width * this.value / 100
    
  }
 
  
    // Getter & Setter for VALUE
  Object.defineProperty(this, 'value', {
    get : () => {
      return this._value
    },
    set : (val) => {
      //console.log("Setting VALUE to " + val);
      if(this._value === val) 
        return
      this._value = Math.floor(val)
      this.redraw()
    }
  })
  
  
}
  